package com.dat.parking.service;

import java.util.List;

import com.dat.parking.model.CarParking;

public interface CarParkingService {
	 void persistInformation(CarParking carParking);
	 public List<CarParking> listCarParkings();
		public List floorTypes(String buildingName, String floorName);
}
