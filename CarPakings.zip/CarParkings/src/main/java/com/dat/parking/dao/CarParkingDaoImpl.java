package com.dat.parking.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.dat.parking.model.CarParking;

@Repository("carParkingDao")
public class CarParkingDaoImpl implements CarParkingDao{

	@Autowired
	private SessionFactory sessionFactory;
	public void persistInformation(CarParking carParking) {
		// TODO Auto-generated method stub
		sessionFactory.getCurrentSession().save(carParking);
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<CarParking> listCarParkings() {
		// TODO Auto-generated method stub
		Session session = this.sessionFactory.getCurrentSession(); 
		List<CarParking> carParkingList = session.createQuery("from CarParking").list();
		for(CarParking p : carParkingList){ 
			
		}
		
		
		return carParkingList;
	}
	
	@Override
	public List floorTypes(String buildingName, String floorName) {
		// TODO Auto-generated method stub
		Session session=this.sessionFactory.getCurrentSession();
		String hql="SELECT building_id FROM CarParking \r\n" + 
				"WHERE buildingName=:buildingName";
		Query query=session.createQuery(hql);
		query.setParameter("buildingName", buildingName).setParameter("floorName", floorName);
		List result=query.list();
		
		return result;
		
	}

}
