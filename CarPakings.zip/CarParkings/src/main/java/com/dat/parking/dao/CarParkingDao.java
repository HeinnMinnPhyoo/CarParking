package com.dat.parking.dao;

import java.util.Date;
import java.util.List;

import com.dat.parking.model.CarParking;


public interface CarParkingDao {

	 void persistInformation(CarParking carParking);
	 public List<CarParking> listCarParkings();
		public List floorTypes(String buildingName, String floorName);
}
